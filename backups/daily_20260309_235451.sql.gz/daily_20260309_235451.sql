--
-- PostgreSQL database dump
--

\restrict IO1YaHO3kmZ7it7lwZ2bC9R9USUsdzZ8gLjczu29wzggx786IJQexWGKEmdEen8

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_messages; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.agent_messages (
    id integer NOT NULL,
    session_id integer,
    role character varying(20) NOT NULL,
    content text,
    tool_calls jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.agent_messages OWNER TO sierra;

--
-- Name: agent_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.agent_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_messages_id_seq OWNER TO sierra;

--
-- Name: agent_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.agent_messages_id_seq OWNED BY public.agent_messages.id;


--
-- Name: agent_sessions; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.agent_sessions (
    id integer NOT NULL,
    chat_id bigint NOT NULL,
    estado character varying(50) DEFAULT 'ativo'::character varying,
    contexto jsonb DEFAULT '{}'::jsonb,
    intent character varying(100),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    corretora_id integer
);

ALTER TABLE ONLY public.agent_sessions FORCE ROW LEVEL SECURITY;


ALTER TABLE public.agent_sessions OWNER TO sierra;

--
-- Name: agent_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.agent_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_sessions_id_seq OWNER TO sierra;

--
-- Name: agent_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.agent_sessions_id_seq OWNED BY public.agent_sessions.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO sierra;

--
-- Name: apolices; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.apolices (
    id integer NOT NULL,
    corretora_id integer,
    cliente_id integer,
    veiculo_id integer,
    cotacao_id integer,
    seguradora character varying(100),
    numero_apolice character varying(50),
    vigencia_inicio date,
    vigencia_fim date,
    premio numeric(12,2),
    franquia numeric(12,2),
    comissao_percentual numeric(5,2),
    comissao_valor numeric(12,2),
    status character varying(20) DEFAULT 'vigente'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    ramo character varying(20),
    nosso_numero character varying(30),
    emissao date,
    proposta character varying(50),
    produtor character varying(100),
    renovacao_status character varying(20) DEFAULT 'pendente'::character varying,
    renovacao_obs text,
    renovacao_updated_at timestamp without time zone
);

ALTER TABLE ONLY public.apolices FORCE ROW LEVEL SECURITY;


ALTER TABLE public.apolices OWNER TO sierra;

--
-- Name: COLUMN apolices.renovacao_status; Type: COMMENT; Schema: public; Owner: sierra
--

COMMENT ON COLUMN public.apolices.renovacao_status IS 'pendente|contatado|cotando|renovado|perdido|cancelado';


--
-- Name: apolices_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.apolices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.apolices_id_seq OWNER TO sierra;

--
-- Name: apolices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.apolices_id_seq OWNED BY public.apolices.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    user_id integer,
    user_nome character varying(100),
    action character varying(50) NOT NULL,
    detail text,
    ip character varying(45),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_log OWNER TO sierra;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO sierra;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: clientes; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.clientes (
    id integer NOT NULL,
    corretora_id integer,
    nome character varying(200) NOT NULL,
    cpf_cnpj character varying(20),
    nascimento date,
    telefone character varying(30),
    email character varying(200),
    cep character varying(10),
    endereco text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    cidade character varying(100),
    uf character varying(2),
    status character varying(10) DEFAULT 'ativo'::character varying,
    drive_pasta text
);

ALTER TABLE ONLY public.clientes FORCE ROW LEVEL SECURITY;


ALTER TABLE public.clientes OWNER TO sierra;

--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.clientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clientes_id_seq OWNER TO sierra;

--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.clientes_id_seq OWNED BY public.clientes.id;


--
-- Name: comissoes; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.comissoes (
    id integer NOT NULL,
    corretora_id integer,
    apolice_id integer,
    usuario_id integer,
    seguradora character varying(100),
    valor numeric(12,2),
    percentual numeric(5,2),
    parcela integer,
    total_parcelas integer,
    data_pagamento date,
    status character varying(20) DEFAULT 'pendente'::character varying,
    created_at timestamp without time zone DEFAULT now()
);

ALTER TABLE ONLY public.comissoes FORCE ROW LEVEL SECURITY;


ALTER TABLE public.comissoes OWNER TO sierra;

--
-- Name: comissoes_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.comissoes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.comissoes_id_seq OWNER TO sierra;

--
-- Name: comissoes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.comissoes_id_seq OWNED BY public.comissoes.id;


--
-- Name: corp_clientes_docs; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.corp_clientes_docs (
    id integer NOT NULL,
    corretora_id integer DEFAULT 1,
    filial character varying(20),
    nosso_numero character varying(50),
    cliente character varying(200),
    cpf_cnpj character varying(20),
    seguradora character varying(100),
    ramo character varying(100),
    apolice character varying(50),
    inicio_vigencia date,
    fim_vigencia date,
    premio numeric(12,2),
    comissao numeric(12,2),
    produtor character varying(200),
    status character varying(50),
    dados_extras jsonb,
    imported_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.corp_clientes_docs OWNER TO sierra;

--
-- Name: corp_clientes_docs_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.corp_clientes_docs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.corp_clientes_docs_id_seq OWNER TO sierra;

--
-- Name: corp_clientes_docs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.corp_clientes_docs_id_seq OWNED BY public.corp_clientes_docs.id;


--
-- Name: corp_export_raw; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.corp_export_raw (
    id integer NOT NULL,
    corretora_id integer DEFAULT 1,
    dados jsonb NOT NULL,
    tipo character varying(50) DEFAULT 'clientes_docs'::character varying,
    imported_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.corp_export_raw OWNER TO sierra;

--
-- Name: corp_export_raw_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.corp_export_raw_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.corp_export_raw_id_seq OWNER TO sierra;

--
-- Name: corp_export_raw_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.corp_export_raw_id_seq OWNED BY public.corp_export_raw.id;


--
-- Name: corp_relatorios; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.corp_relatorios (
    id integer NOT NULL,
    corretora_id integer DEFAULT 1,
    periodo character varying(50),
    mes integer,
    ano integer,
    aba character varying(50),
    producao_total numeric(12,2),
    producao_variacao character varying(20),
    novos numeric(12,2),
    novos_variacao character varying(20),
    renovacoes numeric(12,2),
    renovacoes_variacao character varying(20),
    faturas numeric(12,2),
    endossos numeric(12,2),
    meta_atingida character varying(20),
    seguradoras jsonb,
    ramos jsonb,
    demonstrativo_12m jsonb,
    source_file character varying(100),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.corp_relatorios OWNER TO sierra;

--
-- Name: corp_relatorios_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.corp_relatorios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.corp_relatorios_id_seq OWNER TO sierra;

--
-- Name: corp_relatorios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.corp_relatorios_id_seq OWNED BY public.corp_relatorios.id;


--
-- Name: corretoras; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.corretoras (
    id integer NOT NULL,
    nome character varying(200) NOT NULL,
    cnpj character varying(20),
    regiao character varying(100),
    telefone character varying(30),
    email character varying(200),
    created_at timestamp without time zone DEFAULT now(),
    active boolean DEFAULT true
);


ALTER TABLE public.corretoras OWNER TO sierra;

--
-- Name: corretoras_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.corretoras_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.corretoras_id_seq OWNER TO sierra;

--
-- Name: corretoras_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.corretoras_id_seq OWNED BY public.corretoras.id;


--
-- Name: cotacao_resultados; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.cotacao_resultados (
    id integer NOT NULL,
    cotacao_id integer,
    seguradora character varying(100),
    premio numeric(12,2),
    franquia numeric(12,2),
    parcelas character varying(50),
    numero_cotacao character varying(50),
    mensagem text,
    status character varying(20) DEFAULT 'ok'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    pdf_path character varying(500),
    corretora_id integer
);

ALTER TABLE ONLY public.cotacao_resultados FORCE ROW LEVEL SECURITY;


ALTER TABLE public.cotacao_resultados OWNER TO sierra;

--
-- Name: cotacao_resultados_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.cotacao_resultados_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cotacao_resultados_id_seq OWNER TO sierra;

--
-- Name: cotacao_resultados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.cotacao_resultados_id_seq OWNED BY public.cotacao_resultados.id;


--
-- Name: cotacoes; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.cotacoes (
    id integer NOT NULL,
    corretora_id integer,
    usuario_id integer,
    cliente_id integer,
    veiculo_id integer,
    tipo character varying(20) DEFAULT 'nova'::character varying,
    status character varying(20) DEFAULT 'calculada'::character varying,
    cnh_data jsonb,
    crvl_data jsonb,
    condutor_data jsonb,
    cep_pernoite character varying(10),
    agilizador_url text,
    created_at timestamp without time zone DEFAULT now()
);

ALTER TABLE ONLY public.cotacoes FORCE ROW LEVEL SECURITY;


ALTER TABLE public.cotacoes OWNER TO sierra;

--
-- Name: cotacoes_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.cotacoes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cotacoes_id_seq OWNER TO sierra;

--
-- Name: cotacoes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.cotacoes_id_seq OWNED BY public.cotacoes.id;


--
-- Name: documentos; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.documentos (
    id integer NOT NULL,
    cliente_id integer,
    tipo character varying(30),
    arquivo_path text,
    dados_extraidos jsonb,
    created_at timestamp without time zone DEFAULT now(),
    corretora_id integer
);

ALTER TABLE ONLY public.documentos FORCE ROW LEVEL SECURITY;


ALTER TABLE public.documentos OWNER TO sierra;

--
-- Name: documentos_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.documentos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documentos_id_seq OWNER TO sierra;

--
-- Name: documentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.documentos_id_seq OWNED BY public.documentos.id;


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.login_attempts (
    id integer NOT NULL,
    email character varying(255),
    ip character varying(45),
    success boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.login_attempts OWNER TO sierra;

--
-- Name: login_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.login_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.login_attempts_id_seq OWNER TO sierra;

--
-- Name: login_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.login_attempts_id_seq OWNED BY public.login_attempts.id;


--
-- Name: parcelas; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.parcelas (
    id integer NOT NULL,
    apolice_id integer,
    numero_parcela smallint,
    vencimento date,
    valor numeric(12,2),
    endosso character varying(50),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.parcelas OWNER TO sierra;

--
-- Name: parcelas_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.parcelas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parcelas_id_seq OWNER TO sierra;

--
-- Name: parcelas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.parcelas_id_seq OWNED BY public.parcelas.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    corretora_id integer,
    nome character varying(200) NOT NULL,
    email character varying(200),
    senha_hash character varying(200),
    role character varying(20) DEFAULT 'corretor'::character varying NOT NULL,
    telegram_id bigint,
    telefone character varying(30),
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    last_login timestamp without time zone
);


ALTER TABLE public.usuarios OWNER TO sierra;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_id_seq OWNER TO sierra;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: v_carteira_ativa; Type: VIEW; Schema: public; Owner: sierra
--

CREATE VIEW public.v_carteira_ativa AS
 SELECT cliente,
    cpf_cnpj,
    seguradora,
    ramo,
    apolice,
    inicio_vigencia,
    fim_vigencia,
    premio,
    comissao,
    produtor,
    status,
    (fim_vigencia - CURRENT_DATE) AS dias_restantes
   FROM public.corp_clientes_docs
  WHERE ((fim_vigencia >= CURRENT_DATE) AND ((status IS NULL) OR ((status)::text <> ALL ((ARRAY['Cancelado'::character varying, 'CANCELADO'::character varying, 'Devolvido'::character varying])::text[]))))
  ORDER BY fim_vigencia;


ALTER VIEW public.v_carteira_ativa OWNER TO sierra;

--
-- Name: v_historico_producao; Type: VIEW; Schema: public; Owner: sierra
--

CREATE VIEW public.v_historico_producao AS
 SELECT periodo,
    mes,
    ano,
    aba,
    producao_total,
    producao_variacao,
    novos,
    renovacoes,
    faturas,
    endossos,
    seguradoras,
    ramos
   FROM public.corp_relatorios
  ORDER BY ano, mes, aba;


ALTER VIEW public.v_historico_producao OWNER TO sierra;

--
-- Name: v_producao_mensal; Type: VIEW; Schema: public; Owner: sierra
--

CREATE VIEW public.v_producao_mensal AS
 SELECT (date_trunc('month'::text, (inicio_vigencia)::timestamp with time zone))::date AS mes,
    count(*) AS novos_docs,
    sum(premio) AS premio_novos,
    sum(comissao) AS comissao_novos
   FROM public.corp_clientes_docs
  WHERE (inicio_vigencia IS NOT NULL)
  GROUP BY (date_trunc('month'::text, (inicio_vigencia)::timestamp with time zone))
  ORDER BY ((date_trunc('month'::text, (inicio_vigencia)::timestamp with time zone))::date) DESC;


ALTER VIEW public.v_producao_mensal OWNER TO sierra;

--
-- Name: v_producao_ramo; Type: VIEW; Schema: public; Owner: sierra
--

CREATE VIEW public.v_producao_ramo AS
 SELECT ramo,
    count(*) AS total_docs,
    count(*) FILTER (WHERE (fim_vigencia >= CURRENT_DATE)) AS docs_vigentes,
    sum(premio) AS premio_total,
    sum(comissao) AS comissao_total,
    round(avg(premio), 2) AS ticket_medio,
    round((((count(*))::numeric * 100.0) / NULLIF(sum(count(*)) OVER (), (0)::numeric)), 1) AS perc_carteira
   FROM public.corp_clientes_docs
  WHERE (ramo IS NOT NULL)
  GROUP BY ramo
  ORDER BY (count(*)) DESC;


ALTER VIEW public.v_producao_ramo OWNER TO sierra;

--
-- Name: v_producao_seguradora; Type: VIEW; Schema: public; Owner: sierra
--

CREATE VIEW public.v_producao_seguradora AS
 SELECT seguradora,
    count(*) AS total_docs,
    count(*) FILTER (WHERE (fim_vigencia >= CURRENT_DATE)) AS docs_vigentes,
    sum(premio) AS premio_total,
    sum(comissao) AS comissao_total,
    round(avg(premio), 2) AS ticket_medio,
    round(((sum(comissao) * 100.0) / NULLIF(sum(premio), (0)::numeric)), 1) AS perc_comissao
   FROM public.corp_clientes_docs
  WHERE (seguradora IS NOT NULL)
  GROUP BY seguradora
  ORDER BY (sum(premio)) DESC NULLS LAST;


ALTER VIEW public.v_producao_seguradora OWNER TO sierra;

--
-- Name: v_ranking_clientes; Type: VIEW; Schema: public; Owner: sierra
--

CREATE VIEW public.v_ranking_clientes AS
 SELECT cliente,
    cpf_cnpj,
    count(*) AS total_apolices,
    count(*) FILTER (WHERE (fim_vigencia >= CURRENT_DATE)) AS apolices_ativas,
    sum(premio) AS premio_total,
    sum(comissao) AS comissao_total,
    min(inicio_vigencia) AS cliente_desde,
    array_agg(DISTINCT ramo) AS ramos,
    array_agg(DISTINCT seguradora) AS seguradoras
   FROM public.corp_clientes_docs
  WHERE (cliente IS NOT NULL)
  GROUP BY cliente, cpf_cnpj
  ORDER BY (sum(premio)) DESC NULLS LAST;


ALTER VIEW public.v_ranking_clientes OWNER TO sierra;

--
-- Name: v_renovacoes_pendentes; Type: VIEW; Schema: public; Owner: sierra
--

CREATE VIEW public.v_renovacoes_pendentes AS
 SELECT cliente,
    cpf_cnpj,
    seguradora,
    ramo,
    apolice,
    inicio_vigencia,
    fim_vigencia,
    premio,
    comissao,
    produtor,
    (fim_vigencia - CURRENT_DATE) AS dias_para_vencer,
        CASE
            WHEN ((fim_vigencia - CURRENT_DATE) <= 30) THEN '🔴 URGENTE (30 dias)'::text
            WHEN ((fim_vigencia - CURRENT_DATE) <= 60) THEN '🟡 ATENÇÃO (60 dias)'::text
            WHEN ((fim_vigencia - CURRENT_DATE) <= 90) THEN '🟢 PLANEJAMENTO (90 dias)'::text
            ELSE NULL::text
        END AS prioridade
   FROM public.corp_clientes_docs
  WHERE (((fim_vigencia >= CURRENT_DATE) AND (fim_vigencia <= (CURRENT_DATE + '90 days'::interval))) AND ((status IS NULL) OR ((status)::text <> ALL ((ARRAY['Cancelado'::character varying, 'CANCELADO'::character varying, 'Devolvido'::character varying])::text[]))))
  ORDER BY fim_vigencia;


ALTER VIEW public.v_renovacoes_pendentes OWNER TO sierra;

--
-- Name: v_resumo_geral; Type: VIEW; Schema: public; Owner: sierra
--

CREATE VIEW public.v_resumo_geral AS
 SELECT ( SELECT count(*) AS count
           FROM public.corp_clientes_docs) AS total_registros,
    ( SELECT count(DISTINCT corp_clientes_docs.cliente) AS count
           FROM public.corp_clientes_docs
          WHERE (corp_clientes_docs.cliente IS NOT NULL)) AS total_clientes,
    ( SELECT count(*) AS count
           FROM public.corp_clientes_docs
          WHERE (corp_clientes_docs.fim_vigencia >= CURRENT_DATE)) AS apolices_vigentes,
    ( SELECT count(*) AS count
           FROM public.corp_clientes_docs
          WHERE ((corp_clientes_docs.fim_vigencia >= CURRENT_DATE) AND (corp_clientes_docs.fim_vigencia <= (CURRENT_DATE + 30)))) AS vencem_30_dias,
    ( SELECT count(*) AS count
           FROM public.corp_clientes_docs
          WHERE ((corp_clientes_docs.fim_vigencia >= CURRENT_DATE) AND (corp_clientes_docs.fim_vigencia <= (CURRENT_DATE + 60)))) AS vencem_60_dias,
    ( SELECT count(*) AS count
           FROM public.corp_clientes_docs
          WHERE ((corp_clientes_docs.fim_vigencia >= CURRENT_DATE) AND (corp_clientes_docs.fim_vigencia <= (CURRENT_DATE + 90)))) AS vencem_90_dias,
    ( SELECT sum(corp_clientes_docs.premio) AS sum
           FROM public.corp_clientes_docs
          WHERE (corp_clientes_docs.fim_vigencia >= CURRENT_DATE)) AS premio_carteira_ativa,
    ( SELECT sum(corp_clientes_docs.comissao) AS sum
           FROM public.corp_clientes_docs
          WHERE (corp_clientes_docs.fim_vigencia >= CURRENT_DATE)) AS comissao_carteira_ativa,
    ( SELECT count(DISTINCT corp_clientes_docs.seguradora) AS count
           FROM public.corp_clientes_docs) AS total_seguradoras,
    ( SELECT count(DISTINCT corp_clientes_docs.ramo) AS count
           FROM public.corp_clientes_docs) AS total_ramos;


ALTER VIEW public.v_resumo_geral OWNER TO sierra;

--
-- Name: veiculos; Type: TABLE; Schema: public; Owner: sierra
--

CREATE TABLE public.veiculos (
    id integer NOT NULL,
    cliente_id integer,
    placa character varying(10),
    chassi character varying(30),
    marca_modelo character varying(200),
    ano_fabricacao character varying(4),
    ano_modelo character varying(4),
    cor character varying(30),
    combustivel character varying(30),
    cep_pernoite character varying(10),
    created_at timestamp without time zone DEFAULT now(),
    corretora_id integer
);

ALTER TABLE ONLY public.veiculos FORCE ROW LEVEL SECURITY;


ALTER TABLE public.veiculos OWNER TO sierra;

--
-- Name: veiculos_id_seq; Type: SEQUENCE; Schema: public; Owner: sierra
--

CREATE SEQUENCE public.veiculos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.veiculos_id_seq OWNER TO sierra;

--
-- Name: veiculos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sierra
--

ALTER SEQUENCE public.veiculos_id_seq OWNED BY public.veiculos.id;


--
-- Name: agent_messages id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.agent_messages ALTER COLUMN id SET DEFAULT nextval('public.agent_messages_id_seq'::regclass);


--
-- Name: agent_sessions id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.agent_sessions ALTER COLUMN id SET DEFAULT nextval('public.agent_sessions_id_seq'::regclass);


--
-- Name: apolices id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.apolices ALTER COLUMN id SET DEFAULT nextval('public.apolices_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: clientes id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.clientes ALTER COLUMN id SET DEFAULT nextval('public.clientes_id_seq'::regclass);


--
-- Name: comissoes id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.comissoes ALTER COLUMN id SET DEFAULT nextval('public.comissoes_id_seq'::regclass);


--
-- Name: corp_clientes_docs id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.corp_clientes_docs ALTER COLUMN id SET DEFAULT nextval('public.corp_clientes_docs_id_seq'::regclass);


--
-- Name: corp_export_raw id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.corp_export_raw ALTER COLUMN id SET DEFAULT nextval('public.corp_export_raw_id_seq'::regclass);


--
-- Name: corp_relatorios id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.corp_relatorios ALTER COLUMN id SET DEFAULT nextval('public.corp_relatorios_id_seq'::regclass);


--
-- Name: corretoras id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.corretoras ALTER COLUMN id SET DEFAULT nextval('public.corretoras_id_seq'::regclass);


--
-- Name: cotacao_resultados id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.cotacao_resultados ALTER COLUMN id SET DEFAULT nextval('public.cotacao_resultados_id_seq'::regclass);


--
-- Name: cotacoes id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.cotacoes ALTER COLUMN id SET DEFAULT nextval('public.cotacoes_id_seq'::regclass);


--
-- Name: documentos id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.documentos ALTER COLUMN id SET DEFAULT nextval('public.documentos_id_seq'::regclass);


--
-- Name: login_attempts id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.login_attempts ALTER COLUMN id SET DEFAULT nextval('public.login_attempts_id_seq'::regclass);


--
-- Name: parcelas id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.parcelas ALTER COLUMN id SET DEFAULT nextval('public.parcelas_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Name: veiculos id; Type: DEFAULT; Schema: public; Owner: sierra
--

ALTER TABLE ONLY public.veiculos ALTER COLUMN id SET DEFAULT nextval('public.veiculos_id_seq'::regclass);


--
-- Data for Name: agent_messages; Type: TABLE DATA; Schema: public; Owner: sierra
--

COPY public.agent_messages (id, session_id, role, content, tool_calls, created_at) FROM stdin;
8	2	user	Quero cotar seguro	\N	2026-03-09 23:23:59.766744
9	2	tool_result	{"intencao": "cotacao_nova", "confianca": 0.98, "resumo": "Cliente quer fazer cotação de seguro auto"}	{"tool_use_id": "toolu_01FDJegEy77n5vBUP9nrTc5x"}	2026-03-09 23:24:02.746076
10	2	assistant	Perfeito! Para fazer sua cotação, vou precisar de 3 documentos:\n\n1. **📄 CNH** - sua carteira de habilitação (foto)\n2. **🚗 CRLV** - documento do veículo (foto) \n3. **📍 CEP** - onde o carro dorme/fica guardado\n\nPode começar me enviando uma *foto clara da sua CNH*? Tanto a frente quanto o verso, se tiver informações importantes atrás.	\N	2026-03-09 23:24:07.162557
11	2	user	voces fazem seguro só pra terceiros?	\N	2026-03-09 23:24:31.273927
12	2	tool_result	{"intencao": "duvidas", "confianca": 0.9, "resumo": "Cliente quer saber sobre tipos de cobertura de seguro auto"}	{"tool_use_id": "toolu_01DZSfukZQd6jRWCEym2KwAT"}	2026-03-09 23:24:33.633203
13	2	assistant	Sim, trabalhamos com *todos os tipos* de cobertura! 😊\n\n**Opções disponíveis:**\n• **RC (Terceiros)** - só danos a terceiros, mais econômico\n• **Compreensivo** - cobertura completa (terceiros + casco do seu carro)\n• **Coberturas extras** - vidros, acessórios, carro reserva, etc.\n\nNa cotação, você vai ver as diferentes opções de cada seguradora e pode escolher o que faz mais sentido pro seu bolso e necessidade.\n\n*Quer fazer a cotação?* É só me mandar:\n1. Foto da CNH\n2. Foto do CRLV \n3. CEP onde o carro fica\n\nAí eu te mostro todas as alternativas! 🚗	\N	2026-03-09 23:24:41.63817
\.


--
-- Data for Name: agent_sessions; Type: TABLE DATA; Schema: public; Owner: sierra
--

COPY public.agent_sessions (id, chat_id, estado, contexto, intent, created_at, updated_at, corretora_id) FROM stdin;
